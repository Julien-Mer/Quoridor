package Model;

public class File {

	/**
	 * 
	 * @param fileName
	 * @param data
	 */
	public void writeObject(String fileName, String data) {
		// TODO - implement File.writeObject
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param fileName
	 */
	public Object readObject(String fileName) {
		// TODO - implement File.readObject
		throw new UnsupportedOperationException();
	}

}