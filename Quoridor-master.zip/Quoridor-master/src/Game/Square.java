package Game;

import java.awt.Color;

public class Square {

	private int x;
	private int y;
	private Color color;
	private int attribute;

	/**
	 * the constructor of the class
	 * @param x : horizontal size
	 * @param y : the vertical size
	 */
	public Square(int x, int y) {
		this.x = x;
		this.y = y;
	}

	/**
	 * ???
	 * @param color : ???
	 */
	public void setColor(Color color) {
		this.color = color;
	}
	
	/**
	 * allow to get the color
	 * @return : the color
	 * */
	public Color getColor() {
		return this.color;
	}
	
	/**
	 * allow to get the X positiob 
	 * @return : the x position
	 * */
	public int getX() {
		return this.x;
	}
	
	/**
	 * allow to get the y positiob 
	 * @return : the y position
	 * */
	public int getY() {
		return this.y;
	}

}
