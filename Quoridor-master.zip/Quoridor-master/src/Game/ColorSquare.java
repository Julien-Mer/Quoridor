package Game;

import java.awt.Color;

public class ColorSquare {

	public static final Color BARRIER = null;
	public static final Color FREE = null;
	public static final Color RED = null;
	public static final Color BLUE = null;
	public static final Color GREEN = null;
	public static final Color YELLOW = null;

}