package Server;

import java.util.ArrayList;

import Game.Square;

public class Path {

	private ArrayList<Square> bestPath;
	private ArrayList<Square> newPath;
	private int best;

	/**
	 * 
	 * @param ori
	 * @param dest
	 */
	public ArrayList<Square> getPath(Square ori, Square dest) {
		return null;
	}

	/**
	 * 
	 * @param ori
	 * @param dest
	 */
	public void getPathRec(Square ori, Square dest) {
		
	}

}