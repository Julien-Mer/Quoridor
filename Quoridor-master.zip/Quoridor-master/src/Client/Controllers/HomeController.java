package Client.Controllers;

import Client.*;

public class HomeController {

	/**
	 * the constructor of the class
	 * @param client : ??? 
	 */
	public HomeController(Client client) {

	}

}
