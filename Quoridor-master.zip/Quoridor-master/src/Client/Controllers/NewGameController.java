package Client.Controllers;

import Client.*;

public class NewGameController {

	/**
	 * the constructor of the class
	 * @param client : ??? 
	 */
	public NewGameController(Client client) {

	}

}
