package Client.Controllers;

public class ActionListener {

	/**
	 * 
	 * @param homeController
	 */
	public ActionListener(HomeController homeController) {

	}

	/**
	 * 
	 * @param gameController
	 */
	public ActionListener(GameController gameController) {

	}

	/**
	 * 
	 * @param newGameController
	 */
	public ActionListener(NewGameController newGameController) {

	}

}