package Client.Controllers;

import Client.*;

public class GameController {

	/**
	 * the constructor of the class 
	 * @param client : ??? 
	 */
	public GameController(Client client) {

	}
	
	/**
	 * allow to save the game
	 * */
	public void saveGame() {

	}

}
