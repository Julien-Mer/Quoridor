package Client;

import java.awt.Color;

import Game.*;

public class HumanPlayer {

	private Square position;
	private Square[][] grid;
	private String nom;

	/**
	 * Constructor of the method
	 * @param color: the color of the player 
	 * @param nom : the name of the player 
	 * @param client : ??? 
	 */
	public HumanPlayer(Color color, String nom, Client client) {
	}

	/**
	 * update the board of the game 
	 * @param grid : the grid of the game 
	 */
	public void updateBoard(Square[][] grid) {

	}

	/**
	 * allow to set the position of the player 
	 * @param x : the horizontal position
	 * @param y : the vertical position 
	 */
	public void setPosition(int x, int y) {

	}
	/**
	 * display the grid
	 **/
	public void displayGrid() {

	}

}
