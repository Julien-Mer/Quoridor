package Client;

import java.awt.Color;
import java.io.BufferedWriter;

public class Client {

	private BufferedWriter out;
	private boolean terminal;

	/**
	 * allow to create the player for the game 
	 * @param color: the color of the player 
	 */
	public void createPlayer(Color color) {

	}

	/**
	 * send the data of the game 
	 * @param data: the date of the game
	 */
	public void sendData(String data) {

	}

	/**
	 * Save the game
	 * @param object : ????
	 */
	public void save(Object object) {

	}

	public Client() {

	}
	/**
	 * allow to get the player
	 * @return : The player 
	 * */
	public HumanPlayer getPlayer() {
		return null;
	}

}
