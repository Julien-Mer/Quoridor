package Client.Views;

import javax.swing.JButton;

public class Home {

	private JButton newGameBtn;
	private JButton resumeGameBtn;
	private JButton learningModeBtn;
	
	/**
	 * 
	 * */
	public Home() {
		// TODO - implement Home.Home
		throw new UnsupportedOperationException();
	}

	/**
	 * catch the newGame button
	 *@return : the newGameBtn
	 * */
	public JButton getNewGameBtn() {
		return this.newGameBtn;
	}

	/**
	 *catch the resume button 
	 *@return the resumeGameButton
	 * */
	public JButton getResumeGameBtn() {
		return this.resumeGameBtn;
	}
	
	/**
	 * catch the learning button
	 * @return the learningModeBtn
	 * */
	public JButton getLearningModeBtn() {
		return this.learningModeBtn;
	}

}
