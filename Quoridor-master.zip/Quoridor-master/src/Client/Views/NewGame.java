package Client.Views;

import javax.swing.JButton;

public class NewGame {

	private JButton confirmationBtn;
	private JButton addPlayerBtn;
	private JButton addCapacityBtn;
	
	/**
	 *
	 **/
	public NewGame() {
		// TODO - implement NewGame.NewGame
		throw new UnsupportedOperationException();
	}
	/**
	 *allow to catch the confirmation
	 *@return : the Jbutton confirmationBtn
	 **/
	public JButton getConfirmationBtn() {
		return this.confirmationBtn;
	}
	/**
	 *allow to catch the playerBtn
	 *@return : the PLayer button
	 **/
	public JButton getPlayerBtn() {
		// TODO - implement NewGame.getPlayerBtn
		throw new UnsupportedOperationException();
	}
	/**
	 *allow to catch the confirmation
	 *@return : the Jbutton capacity
	 **/
	public JButton getCapacityBtn() {
		// TODO - implement NewGame.getCapacityBtn
		throw new UnsupportedOperationException();
	}

}
