package Client.Views;

import javax.swing.*;

public class Game {

	private JFrame grid;
	
	/**
	 * ???
	 * */
	public Game() {

	}

	/**
	 * 
	 * @param grid
	 */
	public void setGrid(JFrame grid) {
		this.grid = grid;
	}

}
